let emitters = [];  

function setup() {  
    createCanvas(windowWidth, windowHeight);  
    // Create an emitter at the center  
    emitters.push(new Emitter(width / 2, height / 2));  
}  

function draw() {  
    background(0);  
    for (let emitter of emitters) {  
        emitter.emit();  
        emitter.update();  
        emitter.display();  
    }  
}  

class Emitter {  
    constructor(x, y) {  
        this.position = createVector(x, y);  
        this.particles = [];  
        this.emitRate = 5; // Number of particles to emit each frame  
    }  

    emit() {  
        // Randomly choose the type of particle to emit  
        let particleType = floor(random(3)); // 0, 1, or 2  
        if (particleType === 0) {  
            this.particles.push(new CircleParticle(this.position.x, this.position.y));  
        } else if (particleType === 1) {  
            this.particles.push(new SquareParticle(this.position.x, this.position.y));  
        } else {  
            this.particles.push(new ImageParticle(this.position.x, this.position.y));  
        }  
    }  

    update() {  
        for (let particle of this.particles) {  
            particle.update();  
        }  
        // Remove particles that are off-screen  
        this.particles = this.particles.filter(p => p.isAlive());  
    }  

    display() {  
        for (let particle of this.particles) {  
            particle.display();  
        }  
    }  
}  

// Base Particle class  
class Particle {  
    constructor(x, y) {  
        this.position = createVector(x, y);  
        this.velocity = p5.Vector.random2D().mult(random(2, 5)); // Random direction and speed  
        this.lifespan = 255; // Particle lifespan  
    }  
    
    update() {  
        this.position.add(this.velocity);  
        this.lifespan -= 2; // Decrease lifespan over time  
    }  

    isAlive() {  
        return this.lifespan > 0;  
    }  
}  

// CircleParticle class extends Particle  
class CircleParticle extends Particle {  
    constructor(x, y) {  
        super(x, y);  
        this.color = color(random(255), random(255), random(255)); // Random color for circle  
        this.size = random(5, 15); // Random size for circle  
    }  

    display() {  
        fill(this.color);  
        noStroke();  
        ellipse(this.position.x, this.position.y, this.size, this.size);  
    }  
}  

// SquareParticle class extends Particle  
class SquareParticle extends Particle {  
    constructor(x, y) {  
        super(x, y);  
        this.color = color(random(255), random(255), random(255)); // Random color for square  
        this.size = random(5, 15); // Random size for square  
    }  

    display() {  
        fill(this.color);  
        noStroke();  
        rect(this.position.x, this.position.y, this.size, this.size);  
    }  
}  

// ImageParticle class extends Particle  
class ImageParticle extends Particle {  
    constructor(x, y) {  
        super(x, y);  
        this.size = random(20, 40); // Random size for image particle  
        this.image = loadImage('https://via.placeholder.com/40'); // Loading a placeholder image  
    }  

    display() {  
        image(this.image, this.position.x, this.position.y, this.size, this.size);  
    }  
}  